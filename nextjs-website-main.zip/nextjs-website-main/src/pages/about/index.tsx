import { Button } from "../../components/_ui/Button";

export default function About(){
    return (
        <>
            <h1>About</h1>
            <Button title={"Concluir"}/>
        </>
    )
}